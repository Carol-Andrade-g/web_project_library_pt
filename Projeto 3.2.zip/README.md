# Projeto 3: Biblioteca Triple Peaks

A página da biblioteca Triple Peaks é o terceiro projeto no programa de desenvolvimento web da TripleTen. Ela foi criada usando HTML e CSS, com base no roteiro.

## Recursos do projeto

- HTML5 semântico
- Flexbox
- Posicionamento
